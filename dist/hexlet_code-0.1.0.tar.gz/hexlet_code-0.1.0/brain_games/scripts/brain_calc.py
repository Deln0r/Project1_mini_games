#!/usr/bin/env python3
from random import randint
from random import choice
import prompt


def game_calc():
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    print('What is the result of the expression?')

    def questions():
        count = 0
        while count < 3:
            n1 = randint(1, 25)
            n2 = randint(1, 25)
            oper = choice(['+', '-', '*'])
            result = 0
            if oper == '+':
                result += (n1+n2)
                print(f'Question: {n1} + {n2}')
            elif oper == '-':
                result += (n1-n2)
                print(f'Question: {n1} - {n2}')
            elif oper == '*':
                result += (n1*n2)
                print(f'Question: {n1} * {n2}')
            answer = prompt.string('Your answer: ')
            if answer == result:
                print('Correct!')
                count += 1
            else:
                print(f"'{answer}' is wrong answer ;(. Correct answer was '{result}'.")
                print(f"Let's try again, {name}!")
                break
        if count == 3:
            print(f'Congratulations, {name}!')
    questions()


def main():
    print('Welcome to the Brain Games!')
    game_calc()


if __name__ == '__main__':
    main()
