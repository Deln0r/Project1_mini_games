### Hexlet tests and linter status:
[![Actions Status](https://github.com/Deln0r/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Deln0r/python-project-49/actions)
### Codeclimate Maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/f0e79d67a1916cf0fb18/maintainability)](https://codeclimate.com/github/Deln0r/python-project-49/maintainability)
### asciinema game 1 - even
https://asciinema.org/a/5VPFJCGij3vJxI3jGDvhv37wm
### asciinema game 2 - calc
https://asciinema.org/a/HB3qUZcgVbdwsqyC5d4iv3Puw